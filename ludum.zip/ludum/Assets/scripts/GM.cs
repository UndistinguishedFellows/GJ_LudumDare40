﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GM : MonoBehaviour {
    GameObject player;
    player playerScript;
	// Use this for initialization
	void Start () {
        player = GameObject.FindGameObjectWithTag("Player");
        playerScript = player.GetComponent<player>();
	}
	
	// Update is called once per frame
	void Update () {
		
	}

    public void tileTouched(Vector3 positionTile)
    {
        Debug.Log("iep");
        player.gameObject.transform.position = positionTile;
        GameObject[] tilesW = GameObject.FindGameObjectsWithTag("walkable");
        GameObject[] tilesO = GameObject.FindGameObjectsWithTag("obstacle");
        foreach(GameObject w in tilesW)
        {
            Destroy(w.gameObject);
        }
        foreach (GameObject o in tilesO)
        {
            Destroy(o.gameObject);
        }
        playerScript.mostraWalkables();
    }


}
