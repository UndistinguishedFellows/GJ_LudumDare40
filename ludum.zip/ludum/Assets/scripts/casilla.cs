﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public class casilla : MonoBehaviour {
    [System.Serializable]
	public enum TypeOfCasilla
	{
		Terrain = 0,
		Obstacle = 1,
		Player = 2,
		Enemy = 3
	}

	public TypeOfCasilla tipusCasella;
	public GameObject cTOP, cRIGHT, cDOWN, cLEFT;
	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}



	public void casellaFind(){
		//Debug.Log (transform.position+" soc la casella: "+this.name);
		GameObject[] caselles= GameObject.FindGameObjectsWithTag ("casilla");
		float myX = this.transform.position.x;
		float myY =this.transform.position.y;
		foreach (GameObject c in caselles) {
			
			if (c.gameObject.transform.position.x == myX+1 && c.gameObject.transform.position.y ==myY) {
				cRIGHT = c;
				//Debug.Log ("dreta: "+c.gameObject.transform.position+" name: "+ c.name);
			}
			if (c.gameObject.transform.position.x == myX-1 && c.gameObject.transform.position.y ==myY) {
				cLEFT = c;
				//Debug.Log ("esquerra: "+c.gameObject.transform.position+" name: "+ c.name);
			}
			if (c.gameObject.transform.position.y == myY+1 && c.gameObject.transform.position.x ==myX) {
				cTOP = c;
				//Debug.Log ("adal: "+c.gameObject.transform.position+" name: "+ c.name);
			}
			if (c.gameObject.transform.position.y == myY-1 && c.gameObject.transform.position.x ==myX) {
				cDOWN = c;
				//Debug.Log ("abaix: "+c.gameObject.transform.position+" name: "+ c.name);
			}
		}
	}
}
