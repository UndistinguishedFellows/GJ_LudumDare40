﻿using UnityEngine;
using UnityEditor;
[CustomEditor(typeof(casilla))]
public class customcasella : Editor {

	public override void OnInspectorGUI(){
		base.OnInspectorGUI ();
		casilla casella = (casilla)target;
		if (GUILayout.Button ("custom button")) {
			casella.casellaFind ();
		}
	}

}
