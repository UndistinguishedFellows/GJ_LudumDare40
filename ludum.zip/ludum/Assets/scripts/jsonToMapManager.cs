﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.IO;

public class jsonToMapManager : MonoBehaviour {

    string path;
    public string jsonToLoad;
    string mapJson;
    public GameObject[] suelos;
    public GameObject[] obstaculos;

	void Start () {
        path = Application.streamingAssetsPath +"/"+jsonToLoad+".json";
        mapJson = File.ReadAllText(path);
        visualMapaInfo mapa = JsonUtility.FromJson<visualMapaInfo>(mapJson);
        //Debug.Log("widthMap: " + mapa.widthMap + " heightMap: " + mapa.heightMap);
        for(int i=0;i<mapa.dataMap.Length;i++)
        {
            int a = mapa.dataMap[i];
            float posX = i % mapa.widthMap;
            float posY = -i / mapa.heightMap;
            if (a == 0)
            {
                //Debug.Log(i + " terreny a coordenadas "+posX+" "+posY);
                Vector3 prefabTransform = new Vector3(posX,posY,0);
                Instantiate(suelos[0], prefabTransform, Quaternion.identity);
            }
            else
            {
                //Debug.Log(i + " obstacle a coordenadas " + posX + " "+posY);
                Vector3 prefabTransform = new Vector3(posX, posY, 0);
                Instantiate(obstaculos[0], prefabTransform, Quaternion.identity);
            }
            GameObject[] tiles = GameObject.FindGameObjectsWithTag("casilla");
            foreach(GameObject aTile in tiles)
            {
                aTile.GetComponent<casilla>().casellaFind();
            }
        }
    }
	
	// Update is called once per frame
	void Update () {
		
	}
}
