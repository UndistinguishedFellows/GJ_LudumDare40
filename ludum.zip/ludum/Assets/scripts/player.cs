﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class player : MonoBehaviour {
    public int movement=0;
    public float speed=0.0f;
    public Vector3 position= new Vector3(0,0,0);
    public GameObject wallkable,obstacle;

    public unit _player;
	// Use this for initialization
	void Start () {
        _player = new unit(movement, speed);

        Debug.Log("el jugador es pot moure " + _player.movement);
        Debug.Log("el jugador es mou a una velocitat de " + _player.speed);
        transform.position = position;
        mostraWalkables();
    }
	
	// Update is called once per frame
	void Update () {
        
    }

    public void mostraWalkables()
    {
        GameObject[] tiles = GameObject.FindGameObjectsWithTag("casilla");
        foreach(GameObject tile in tiles)
        {
            float posXTile = tile.gameObject.transform.position.x;
            float posYTile = tile.gameObject.transform.position.y;
            if((Mathf.Abs(posXTile - transform.position.x)+ Mathf.Abs(posYTile - transform.position.y))>0 && (Mathf.Abs(posXTile - transform.position.x) + Mathf.Abs(posYTile - transform.position.y)) <= _player.movement)
            {
                Debug.Log("distancia: "+(Mathf.Abs(posXTile - transform.position.x) + Mathf.Abs(posYTile - transform.position.y)));
                Debug.Log(tile.gameObject.GetComponent<casilla>().tipusCasella);
                
                Debug.Log("posX:" + posXTile);
                Debug.Log("posY:" + posYTile);
                if (tile.gameObject.GetComponent<casilla>().tipusCasella.Equals(casilla.TypeOfCasilla.Terrain)){ 
                    Instantiate(wallkable,new Vector3(posXTile,posYTile,0),Quaternion.identity);
                }else
                {
                    Instantiate(obstacle, new Vector3(posXTile, posYTile, 0), Quaternion.identity);
                }
            }
        }

    }

}
