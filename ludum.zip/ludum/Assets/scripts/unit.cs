﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
[System.Serializable]
public class unit
{
    public int movement;
    public float speed;
    public unit(int _movement, float _speed)
    {
        movement = _movement;
        speed = _speed;
    }
    public void setSpeed(float _speed)
    {
        speed = _speed;
    }
    public void setMovement(int _movement)
    {
        movement = _movement;
    }


}
