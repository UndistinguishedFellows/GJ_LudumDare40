﻿[System.Serializable]
public class visualMapaInfo {
    public int widthMap, heightMap;
    public int[] dataMap;
}
