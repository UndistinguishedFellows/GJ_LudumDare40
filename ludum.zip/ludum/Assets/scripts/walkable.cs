﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class walkable : MonoBehaviour {
    GameObject GM;
    GM gm;
	// Use this for initialization
	void Start () {
        GM = GameObject.FindGameObjectWithTag("GM");
        gm = GM.GetComponent<GM>();
	}
	
	// Update is called once per frame
	void Update () {
		
	}
    void OnMouseDown()
    {
        gm.tileTouched(new Vector3(transform.position.x,transform.position.y,0));
    }
}
